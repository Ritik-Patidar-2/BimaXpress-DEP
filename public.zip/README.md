# bimaexpress repo
# installtion guid
npm install

## creating build
npm run build

## starting fronend
npm start
This is Repository for react code
